package com.demo.SprinCloudContractFrz;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
public class SprinCloudContractFrzApplicationTests {//extends AbstractTest{

	@Test
	public void contextLoads() {
	}
		/*@Test
		public  void should_give_me_a_beer_when_im_old_enough() throws Exception{

		}
		@Test
		public void should_reject_a_beer_when_im_too_young() throws Exception{

		}*/

}
