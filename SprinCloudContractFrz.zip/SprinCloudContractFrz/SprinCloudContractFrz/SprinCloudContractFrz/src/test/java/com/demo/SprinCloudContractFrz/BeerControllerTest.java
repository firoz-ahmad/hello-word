package com.demo.SprinCloudContractFrz;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
public class BeerControllerTest extends AbstractTest{

    @Autowired
    MockMvc mockMvc;
   // Byte[] json;
    @Test
    public  void should_give_me_a_beer_when_im_old_enough() throws Exception{

         mockMvc.perform(post("/beer")
                         .contentType(MediaType.TEXT_PLAIN)
                         .content("hi"))
                          .andExpect(status().isOk())
                          .andExpect(content().string("hi"));

    }
   /* @Test
    public void should_reject_a_beer_when_im_too_young() throws Exception{

        mockMvc.perform(post("/beer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json.write(new Person("firoz",22)).getJson()))
                .andExpect(status().isOk())
                .andExpect(content().string("There you go"));

    }*/
   @Test
   public void should_reject_a_beer_when_im_too_young() throws Exception{

       mockMvc.perform(post("/beer")
               .contentType(MediaType.TEXT_PLAIN)
               .content("bye"))
               .andExpect(status().isOk())
               .andExpect(content().string("bye"));

   }
}
