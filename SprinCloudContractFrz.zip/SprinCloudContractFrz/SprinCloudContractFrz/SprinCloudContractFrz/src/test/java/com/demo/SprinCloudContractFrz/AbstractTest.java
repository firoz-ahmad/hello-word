package com.demo.SprinCloudContractFrz;

public abstract class AbstractTest {

    public abstract void should_give_me_a_beer_when_im_old_enough() throws Exception;
    public abstract void should_reject_a_beer_when_im_too_young() throws Exception;
}
