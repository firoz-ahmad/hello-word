package com.demo.SprinCloudContractFrz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.awt.*;

@RestController
public class BeerController {
   // @Autowired
    //private  RestTemplate restTemplate;

    /*BeerController(RestTemplate restTemplate){
        this.restTemplate=restTemplate;
    }*/

    @RequestMapping(method = RequestMethod.POST,value = "/beer",consumes = MediaType.TEXT_PLAIN_VALUE)
    public String gimmeABeer(@RequestBody String person) throws Exception{
        System.out.println("III LLLLLLLLLLLLLL FFFFFFFFFFFFFFFFFFFF"+person);
        return "hi";
    }

  /*  @RequestMapping(method = RequestMethod.POST,value = "/beer",consumes = MediaType.APPLICATION_JSON_VALUE)
    public String gimmeABeer(@RequestBody Person person) throws Exception{
        return null;
    }*/

}

class Person{
    public String name;
    public int age;

   public Person(){}
  Person(String name, int age){
      this.name=name;
      this.age=age;
  }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
class Response {
    public ResponseStatus status;
}
enum ResponseStatus{
    OK,NOT_OK
}